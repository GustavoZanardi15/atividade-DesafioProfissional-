import { Usuario, Tarefa, Categoria } from './types';

export let usuarios: Usuario[] = [];
export let tarefas: Tarefa[] = [];
export let categorias: Categoria[] = [];