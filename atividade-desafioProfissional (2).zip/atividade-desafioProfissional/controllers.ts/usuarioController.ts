import { Request, Response } from 'express';
import { Usuario } from './types';
import { usuarios } from './db';

export const registroUsuario = (req: Request, res: Response) => {
    const novoUsuario: Usuario = req.body;
};

export const loginUsuario = (req: Request, res: Response) => {
};