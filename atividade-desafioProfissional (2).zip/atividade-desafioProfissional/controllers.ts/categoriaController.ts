import { Request, Response } from 'express';
import { Categoria } from './types';
import { categorias } from './db';

export const criarCategoria = (req: Request, res: Response) => {
    const novaCategoria: Categoria = req.body;

};

export const atualizarCategoria = (req: Request, res: Response) => {
    const idCategoria = parseInt(req.params.idCategoria);
    const categoriaAtualizada: Categoria = req.body;
  
};

export const excluirCategoria = (req: Request, res: Response) => {
    const idCategoria = parseInt(req.params.idCategoria);

};