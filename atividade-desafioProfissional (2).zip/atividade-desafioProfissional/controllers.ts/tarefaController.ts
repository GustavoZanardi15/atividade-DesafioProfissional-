import { Request, Response } from 'express';
import { Tarefa } from './types';
import { tarefas } from './db';

export const criarTarefa = (req: Request, res: Response) => {
    const novaTarefa: Tarefa = req.body;
  
};

export const atualizarTarefa = (req: Request, res: Response) => {
    const idTarefa = parseInt(req.params.idTarefa);
    const tarefaAtualizada: Tarefa = req.body;

};

export const excluirTarefa = (req: Request, res: Response) => {
    const idTarefa = parseInt(req.params.idTarefa);
};