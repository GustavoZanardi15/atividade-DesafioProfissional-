import express from 'express';
import { criarTarefa, atualizarTarefa, excluirTarefa } from './tarefaController';

const router = express.Router();

router.post('/', criarTarefa);
router.put('/:idTarefa', atualizarTarefa);
router.delete('/:idTarefa', excluirTarefa);

export default router;