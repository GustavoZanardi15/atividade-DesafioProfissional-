import express from 'express';
import { registroUsuario, loginUsuario } from './usuarioController';

const router = express.Router();

router.post('/registro', registroUsuario);
router.post('/login', loginUsuario);

export default router;