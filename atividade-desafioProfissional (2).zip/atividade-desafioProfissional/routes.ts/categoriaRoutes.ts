import express from 'express';
import { criarCategoria, atualizarCategoria, excluirCategoria } from './categoriaController';

const router = express.Router();

router.post('/', criarCategoria);
router.put('/:idCategoria', atualizarCategoria);
router.delete('/:idCategoria', excluirCategoria);

export default router;